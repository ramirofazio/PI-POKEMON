import React, { useEffect } from "react";
import { NavLink } from "react-router-dom";
import { getPokemons } from "../../actions";
import { useDispatch } from "react-redux";
import style from "./Landing.module.css";
import "normalize.css";
import pikachu from "../../assets/pikachu.png";

export default function Landing() {
  const dispatch = useDispatch();

  useEffect(() => {
    //cargo los pokes en el estado cuando se monta el componente
    dispatch(getPokemons());
  }, []);

  return (
    <div class={style.container}>
      <h1>POKEMON</h1>

      <img src={pikachu} class={style.img} />

      <NavLink to="/home" class={style.button}>
        GO!
      </NavLink>
    </div>
  );
}
