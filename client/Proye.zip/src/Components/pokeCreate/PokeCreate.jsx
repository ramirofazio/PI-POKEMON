import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getTypes, clearStates, postPokemon } from "../../actions";
import { Link } from "react-router-dom";
import swal from "sweetalert";
import style from "./PokeCreate.module.css";

export default function PokeCreate() {
  const dispatch = useDispatch();
  const types = useSelector((state) => state.types); //selecciono state.types en types
  const pokemons = useSelector((state) => state.pokemons);

  //--------------------CREO ESTADO LOCAL----------------------------
  const [newPoke, setNewPoke] = useState({
    name: "",
    hp: "",
    strenght: "",
    defense: "",
    speed: "",
    height: "",
    weight: "",
    img: "",
    types: [],
  });

  //------------------USE EFFECT--------------------------
  useEffect(() => {
    dispatch(getTypes()); //Me traigo los types para poder usarlos
  }, []);

  //---------------HANDLE BUTTON HOME-----------------
  const handleOnClickHome = () => {
    dispatch(clearStates());
  };

  return (
    <div class={style.container}>
      {/*---------BUTTON HOME-------------------- */}
      <div class={style.buttonHome}>
        <Link to="/home">
          <button
            onClick={() => {
              handleOnClickHome();
            }}
          >
            Home
          </button>
        </Link>
      </div>
      {/*-----------INPUT CREAT------------------------ */}
      <div class={style.form}>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            console.log(newPoke);
            dispatch(postPokemon(newPoke));
            setNewPoke({
              name: "",
              hp: "",
              strenght: "",
              defense: "",
              speed: "",
              height: "",
              weight: "",
              img: "",
              types: [],
            }); //Borro los campos
            swal("Pokemon Succesfully Created!", "", "success");
          }}
        >
          <input
            class={style.form_input}
            type="text"
            placeholder="Name..."
            value={newPoke.name}
            onChange={(e) => {
              const res = e.target.value.toLowerCase();
              setNewPoke({
                ...newPoke,
                name: res,
              });
            }}
          />
          <input
            class={style.form_input}
            type="number"
            placeholder="Life..."
            value={newPoke.hp}
            onChange={(e) => {
              const res = e.target.value;
              res <= 100 && res >= 0
                ? setNewPoke({
                    ...newPoke,
                    hp: res,
                  })
                : swal("Select a number from 1-100", "", "error");
            }}
          />
          <input
            class={style.form_input}
            type="number"
            placeholder="Attack..."
            value={newPoke.strenght}
            onChange={(e) => {
              const res = e.target.value;
              res <= 100 && res >= 0
                ? setNewPoke({
                    ...newPoke,
                    strenght: res,
                  })
                : swal("Select a number from 1-100", "", "error");
            }}
          />
          <input
            class={style.form_input}
            type="number"
            placeholder="Defense..."
            value={newPoke.defense}
            onChange={(e) => {
              const res = e.target.value;
              res <= 100 && res >= 0
                ? setNewPoke({
                    ...newPoke,
                    defense: res,
                  })
                : swal("Select a number from 1-100", "", "error");
            }}
          />
          <input
            class={style.form_input}
            type="number"
            placeholder="Speed..."
            value={newPoke.speed}
            onChange={(e) => {
              const res = e.target.value;
              res <= 100 && res >= 0
                ? setNewPoke({
                    ...newPoke,
                    speed: res,
                  })
                : swal("Select a number from 1-100", "", "error");
            }}
          />
          <input
            class={style.form_input}
            type="number"
            placeholder="Height..."
            value={newPoke.height}
            onChange={(e) => {
              const res = e.target.value;
              res <= 100 && res >= 0
                ? setNewPoke({
                    ...newPoke,
                    height: res,
                  })
                : swal("Select a number from 1-100", "", "error");
            }}
          />
          <input
            class={style.form_input}
            type="number"
            placeholder="Weight..."
            value={newPoke.weight}
            onChange={(e) => {
              const res = e.target.value;
              res <= 100 && res >= 0
                ? setNewPoke({
                    ...newPoke,
                    weight: res,
                  })
                : swal("Select a number from 1-100", "", "error");
            }}
          />
          <input
            class={style.form_input}
            type="url"
            placeholder="Image URL..."
            value={newPoke.img}
            attern="https://.*"
            onChange={(e) => {
              const res = e.target.value;
              setNewPoke({
                ...newPoke,
                img: res,
              });
            }}
          />

          <input
            type="submit"
            value="Add To PokeFamily!"
            class={style.form_submit}
          />
        </form>
      </div>
      {/*-------------TYPES CHEKBOXS-------------------- */}

      <div class="checkbox">
        {types.map((type, index) => (
          <label>
            <div class={style.checkbox_type}>
              {type.name + ":"}
              <input
                type={style.checkbox}
                id={index + 1}
                value={type.name}
                onChange={(e) =>
                  newPoke.types.length !== 2
                    ? setNewPoke({
                        ...newPoke,
                        types: [...newPoke.types, e.target.id],
                      })
                    : swal("Only select 2 Types!", "", "error")
                }
              />
            </div>
          </label>
        ))}
      </div>
    </div>
  );
}
