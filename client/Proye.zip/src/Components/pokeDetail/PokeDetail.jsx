import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getPokemonsId, clearStates, getPokemons } from "../../actions";
import { Link } from "react-router-dom";
import style from "./PokeDetail.module.css";

export default function PokeDetail({ id }) {
  const dispatch = useDispatch();
  const pokemonDetail = useSelector((state) => state.pokemonDetail);

  useEffect(() => {
    dispatch(getPokemonsId(id));
    dispatch(clearStates());
    dispatch(getPokemons());
  }, []);

  let nuevosTypes = [];
  if (typeof id === "string") {
    pokemonDetail.types?.filter((type) => nuevosTypes.push(type.name));
    //console.log(nuevosTypes);
  }

  //console.log(pokemonDetail);

  return (
    <div class={style.container}>
      <div class={style.buttonHome}>
        <Link to="/home">
          <button>Go Home</button>
        </Link>
      </div>
      <div class={style.info}>
        <p class={style.info_name}>Name: {pokemonDetail.name}</p>
        <p class={style.info_hp}>HP: {pokemonDetail.hp}</p>
        <p class={style.info_defense}>Defense: {pokemonDetail.defense}</p>
        <p class={style.info_height}>Height: {pokemonDetail.height}</p>
        <p class={style.info_weight}>Weight: {pokemonDetail.weight}</p>
        <p class={style.info_speed}>Speed: {pokemonDetail.speed}</p>
        <p class={style.info_strength}>Attack: {pokemonDetail.strength}</p>
        <img src={pokemonDetail.img} alt="" class={style.img} />
        <p class={style.info_types}>
          Types:{" "}
          {typeof id === "string"
            ? nuevosTypes.join(", ")
            : pokemonDetail.types?.join(", ")}
        </p>
      </div>
    </div>
  );
}
