import React from "react";

export default function Paginado({ pokemonsPerPage, pokemons, paginado }) {
  const pageNumbers = [];

  for (let i = 1; i <= Math.ceil(pokemons / pokemonsPerPage); i++) {
    pageNumbers.push(i);
  }

  return (
    <div class="container">
      <nav>
        <ul class="paginado">
          {pageNumbers &&
            pageNumbers.map((number) => (
              <button onClick={() => paginado(number)}>{number}</button>
            ))}
        </ul>
      </nav>
    </div>
  );
}
